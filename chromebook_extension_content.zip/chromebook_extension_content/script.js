const CM_API_KEY = "6y854YzZqlfQbU2"
const URL_REGISTRY_HISTORY = "https://data-colectors-f7pfklwiqq-uc.a.run.app"
const DEBUG = false
const PERIOD_SEND_DATA = 10
const PERIOD_SEND_DATA_RETRY = 1
const START_HOUR_SEND_DATA = 7
const END_HOUR_SEND_DATA = 19

var isFirstTime = true
let startTime = new Date().getTime()
let historyDomains = []
let email = ""
let num_tabs = 0

function subtractMinutes(numOfMinutes, date = new Date()) {
    const dateCopy = new Date(date.getTime())
    dateCopy.setMinutes(dateCopy.getMinutes() - numOfMinutes)
    return dateCopy
}

async function getEmail() {
    await chrome.identity.getProfileUserInfo({ 'accountStatus': 'ANY' },
        function (info) {
            email = info.email
            logInfo(email)
        })
}

function logInfo(...info) {
    if (DEBUG) {
        console.log(info)
    }
}

async function getHistory(delay=PERIOD_SEND_DATA) {
    startTime = subtractMinutes(delay).getTime()

    await chrome.history.search({ startTime: startTime, text: '', maxResults: 0 }, async function (historyItems) {
        let url = ""
        let domains = []
        await historyItems.forEach(function (historyItem) {
            url = historyItem?.url
            const { hostname } = new URL(url)
            domains.push({
                "domain": hostname,
                "title": historyItem?.title,
            })
        })
        postRegisterHistory(domains)
    })
}

async function postRegisterHistory(history) {

    logInfo(history)

    if (email) {
        fetch(`${URL_REGISTRY_HISTORY}/api/v1/workspaceapp/history?email=${email}`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Accept': 'application/json, *.*',
                'Content-Type': 'application/json charset=utf-8',
                'CM-API-KEY': CM_API_KEY
            },
            body: JSON.stringify(history)
        })
            .then(response => response.json())
            .then(data => {
                logInfo('Success:', data)
                chrome.alarms.create('send', { periodInMinutes: PERIOD_SEND_DATA })
            })
            .catch((error) => {
                logInfo('Error:', error)
                chrome.alarms.create('send', { periodInMinutes: PERIOD_SEND_DATA_RETRY })
            })
    }
}


chrome.tabs.onCreated.addListener(async function (tab) {
    logInfo("tab created", tab, isFirstTime)
   
    num_tabs++
    if (!isFirstTime)
        return
    
    const now = new Date()
    if (!(now.getHours() >= START_HOUR_SEND_DATA && now.getHours() <= END_HOUR_SEND_DATA))
        return

    chrome.tabs.query({}, tabs => {
        for (var index in tabs) {
            if (tabs[index].url?.includes("cm-ext=ok")) {
                isFirstTime = false
            }
            logInfo(tabs[index].url)
        }
        if (isFirstTime) {
            logInfo("first time")
            chrome.tabs.update(tab.id, {
                url: chrome.runtime.getURL("index.html?cm-ext=ok")
            })
            isFirstTime = false
        }
    })
})

chrome.alarms.onAlarm.addListener(async (alarm) => {
    let now = new Date()
    if (now.getHours() >= START_HOUR_SEND_DATA && now.getHours() <= END_HOUR_SEND_DATA) {
        await getEmail()
        await getHistory()
    }
})

chrome.runtime.onInstalled.addListener(async () => {
    logInfo("installed")
    chrome.alarms.create('send', { periodInMinutes: PERIOD_SEND_DATA })
})

chrome.tabs.onRemoved.addListener(async function (tabId) {
    num_tabs--
    if (num_tabs == 0) {
        let delay = Math.ceil((new Date().getTime() - startTime) / 1000 / 60 / 60)
        logInfo("delay", delay, new Date().getTime(), startTime, email)
        getHistory(delay)
    }
})