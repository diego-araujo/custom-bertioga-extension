﻿const LIST_ALLOWED_APPS = [
    {
        "title": "Book Creator",
        "allow": true,
        "path": "assets/images/book_creator.png",
        "url": "https://bookcreator.com",
        "openAction": "website"
    },
    {
        "title": "Canva",
        "allow": true,
        "path": "assets/images/canva.png",
        "url": "https://canva.com/",
        "openAction": "website"
    },
    {
        "title": "Classroomscreen",
        "allow": true,
        "path": "assets/images/classroomscreen.png",
        "url": "https://classroomscreen.com/",
        "openAction": "website"
    },
    {
        "title": "Flippity",
        "allow": true,
        "path": "assets/images/flippity.png",
        "url": "https://flippity.net/",
        "openAction": "website"
    },
    {
        "title": "Geocaching",
        "allow": true,
        "path": "assets/images/geocaching.png",
        "url": "",
        "openAction": "app",
        "packageName": "com.groundspeak.geocaching.intro"
    },
    {
        "title": "Globe observer",
        "allow": true,
        "path": "assets/images/globe_observer.png",
        "url": "https://www.globe.gov/",
        "openAction": "website"
    },
    {
        "title": "Google Agenda",
        "allow": true,
        "path": "assets/images/google_calendar.png",
        "url": "https://calendar.google.com/calendar/u/0/",
        "openAction": "website"
    },
    {
        "title": "Google Apresentações",
        "allow": true,
        "path": "assets/images/google_presentation.png",
        "url": "https://docs.google.com/presentation/u/0/",
        "openAction": "website"
    },
    {
        "title": "Google Chat",
        "allow": true,
        "path": "assets/images/google_chat.png",
        "url": "https://workspace.google.com/intl/pt-BR/products/chat/",
        "openAction": "website"
    },
    {
        "title": "Google Classroom",
        "allow": true,
        "path": "assets/images/google_classroom.png",
        "url": "https://classroom.google.com/u/0/",
        "openAction": "website"
    },
    {
        "title": "Google Docs",
        "allow": true,
        "path": "assets/images/google_docs.png",
        "url": "https://docs.google.com/document/u/0/?hl=pt-BR/",
        "openAction": "website"
    },
    {
        "title": "Google Drive",
        "allow": true,
        "path": "assets/images/google_drive.png",
        "url": "https://drive.google.com/drive/u/1/my-drive",
        "openAction": "website"
    },
    {
        "title": "Google Earth",
        "allow": true,
        "path": "assets/images/google_earth.png",
        "url":
            "https://earth.google.com/web/search/bertioga/@-23.83334754,-46.11513363,1.77806933a,13643.01436495d,35y,359.99974906h,0t,0r",
        "openAction": "website"
    },
    {
        "title": "Google Forms",
        "allow": true,
        "path": "assets/images/google_forms.png",
        "url": "https://docs.google.com/forms/u/0/",
        "openAction": "website"
    },
    {
        "title": "Google Jamboard",
        "allow": true,
        "path": "assets/images/google_jamboard.png",
        "url": "https://jamboard.google.com/",
        "openAction": "website"
    },
    {
        "title": "Google Meet",
        "allow": true,
        "path": "assets/images/google_meet.png",
        "url": "https://meet.google.com/",
        "openAction": "website"
    },
    {
        "title": "Google Planilhas",
        "allow": true,
        "path": "assets/images/google_sheets.png",
        "url": "https://docs.google.com/spreadsheets/u/0/",
        "openAction": "website"
    },
    {
        "title": "Google Street View",
        "allow": true,
        "path": "assets/images/google_street_view.png",
        "url":
            "https://www.google.com.br/maps/@-23.8312343,-46.1301937,8512m/data=!3m1!1e3?hl=pt-PT/",
        "openAction": "website"
    },
    {
        "title": "iNaturalist",
        "allow": true,
        "path": "assets/images/inaturalist.png",
        "url": "https://www.inaturalist.org/",
        "openAction": "website"
    },
    {
        "title": "Kahoot",
        "allow": true,
        "path": "assets/images/kahoot.png",
        "url": "https://kahoot.it",
        "openAction": "website"
    },
    {
        "title": "Khan Academy",
        "allow": true,
        "path": "assets/images/khan_academy.png",
        "url": "https://pt.khanacademy.org/",
        "openAction": "website"
    },
    {
        "title": "Menti",
        "allow": true,
        "path": "assets/images/mentimeter.png",
        "url": "https://menti.com/",
        "openAction": "website"
    },
    {
        "title": "Mentimeter",
        "allow": true,
        "path": "assets/images/mentimeter.png",
        "url": "https://mentimeter.com/pt-BR/",
        "openAction": "website"
    },
    {
        "title": "Merlin",
        "allow": true,
        "path": "assets/images/merlin_bird_id.png",
        "url": "https://merlin.allaboutbirds.org/",
        "openAction": "website"
    },
    {
        "title": "Mind Lab",
        "allow": true,
        "path": "assets/images/mind_lab.png",
        "url": "https://app.mindzup.com.br/",
        "openAction": "website"
    },
    {
        "title": "Natu Contos NF",
        "allow": true,
        "path": "assets/images/natu_contos.png",
        "url": "http://www.natucontos.com/",
        "openAction": "website"
    },
    {
        "title": "PadLet",
        "allow": true,
        "path": "assets/images/padlet.png",
        "url": "https://pt-br.padlet.com/",
        "openAction": "website"
    },
    {
        "title": "Scratch",
        "allow": true,
        "path": "assets/images/scratch_jr.png",
        "url": "https://scratch.mit.edu/",
        "openAction": "website"
    },
    {
        "title": "Star Walk",
        "allow": true,
        "path": "assets/images/star_walk.png",
        "url": "",
        "openAction": "app",
        "packageName": "com.vitotechnology.StarWalk2Free"
    },
    {
        "title": "Thing Link",
        "allow": true,
        "path": "assets/images/thing_link.png",
        "url": "https://thinglink.com",
        "openAction": "website"
    },
    {
        "title": "Tinkercad",
        "allow": true,
        "path": "assets/images/tinkercad.png",
        "url": "https://tinkercad.com/",
        "openAction": "website"
    },
    {
        "title": "Wordwall",
        "allow": true,
        "path": "assets/images/wordwall.png",
        "url": "https://wordwall.net/pt",
        "openAction": "website"
    },
]

const LIST_ALLOWED_WEBSITES = [
    {
        "title": "Secretaria da Educação",
        "allow": true,
        "path": "assets/images/bertioga_logo.png",
        "url":
            "https://sites.google.com/seducbertioga.com.br/bertiogaedu/in%C3%ADcio/",
        "openAction": "website"
    },
    {
        "title": "Área do Professor",
        "allow": true,
        "path": "assets/images/quadro_escolar.png",
        "url":
            "https://sites.google.com/seducbertioga.com.br/professor/in%C3%ADcio/",
        "openAction": "website"
    },
    {
        "title": "Atividades passatempo",
        "allow": true,
        "path": "assets/images/passa_tempo.png",
        "url":
            "https://sites.google.com/seducbertioga.com.br/bertiogaedu/atividades-passatempo/",
        "openAction": "website"
    },
]

function showIcons() {
    web.innerHTML += `<div class="card"/>`
    for (var i = 0; i < LIST_ALLOWED_WEBSITES.length; i++) {
        web.innerHTML += `
        <div class="card">
        <a href=${LIST_ALLOWED_WEBSITES[i].url} target="_blank">
        <img src=${LIST_ALLOWED_WEBSITES[i].path} alt=""/>
        </a>${LIST_ALLOWED_WEBSITES[i].title}
        </div>`
    }
    web.innerHTML += `<div class="card"/>`
    for (var i = 0; i < LIST_ALLOWED_APPS.length; i++) {
        app.innerHTML += `<div class="card">
        <a href=${LIST_ALLOWED_APPS[i].url} target="_blank"
        ><img src=${LIST_ALLOWED_APPS[i].path} alt=""/>
        </a>${LIST_ALLOWED_APPS[i].title}
        </div>
        `
    }
}

// Disable Enter
window.addEventListener('keydown', function (e) {
    if (e.keyIdentifier == 'U+000A' || e.keyIdentifier == 'Enter' || e.keyCode == 13) {
        if (e.target.nodeName == 'INPUT' && e.target.type == 'text') {
            e.preventDefault(); return false;
        }
    }
}, true);

window.onload = function () {
    var app = document.getElementById('app')
    var web = document.getElementById('web')
    var button_web = document.getElementById('btn-web')
    var button_app = document.getElementById('btn-app')
    var input_search = document.getElementById('simple-search')
    var indicator_app = document.getElementById('indicator-app')
    var indicator_web = document.getElementById('indicator-web')
    button_web.addEventListener('click', function () {
        app.classList.add("hidden")
        web.classList.remove("hidden")
        indicator_web.classList.add("mdc-tab-indicator", "mdc-tab-indicator--active")
        indicator_app.classList.remove("mdc-tab-indicator")
        indicator_app.classList.remove("mdc-tab-indicator--active")
    })
    button_app.addEventListener('click', function () {
        web.classList.add("hidden")
        app.classList.remove("hidden")
        indicator_app.classList.add("mdc-tab-indicator", "mdc-tab-indicator--active")
        indicator_web.classList.remove("mdc-tab-indicator")
        indicator_web.classList.remove("mdc-tab-indicator--active")
    })
    input_search.addEventListener('keyup', function () {

        web.innerHTML = ""
        app.innerHTML = ""

        if (input_search.value === "") {
            showIcons()
            return
        }
        web.innerHTML += `<div class="card"/>`
        for (var i = 0; i < LIST_ALLOWED_WEBSITES.length; i++) {
            if (LIST_ALLOWED_WEBSITES[i].title.toLowerCase().includes(input_search.value.toLowerCase())) {
                web.innerHTML += `
                <a href=${LIST_ALLOWED_WEBSITES[i].url} target="_blank">
                <img src=${LIST_ALLOWED_WEBSITES[i].path} alt=""/>
                </a>${LIST_ALLOWED_WEBSITES[i].title}
                </div>`
            }
        }
        web.innerHTML += `<div class="card"/>`
        for (var i = 0; i < LIST_ALLOWED_APPS.length; i++) {
            if (LIST_ALLOWED_APPS[i].title.toLowerCase().includes(input_search.value.toLowerCase())) {
                app.innerHTML += `<div class="card">
                <a href=${LIST_ALLOWED_APPS[i].url} target="_blank"
                ><img src=${LIST_ALLOWED_APPS[i].path} alt=""/>
                </a>${LIST_ALLOWED_APPS[i].title}
                </div>
                `
            }
        }
    })

    showIcons()
}